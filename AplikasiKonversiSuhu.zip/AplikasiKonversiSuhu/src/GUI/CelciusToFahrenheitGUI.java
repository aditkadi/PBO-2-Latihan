package GUI;

import javax.swing.JOptionPane;
import com.sun.glass.events.KeyEvent;

public class CelciusToFahrenheitGUI extends javax.swing.JFrame {
    public CelciusToFahrenheitGUI() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelGUI = new javax.swing.JPanel();
        jLabelCelcius = new javax.swing.JLabel();
        jLabelFahrenheit = new javax.swing.JLabel();
        jbtnConvert = new javax.swing.JButton();
        jtfCelcius = new javax.swing.JTextField();
        jbtnKeluar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Konversi Suhu C To F");
        setBackground(new java.awt.Color(204, 204, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabelCelcius.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabelCelcius.setText("Celcius");

        jLabelFahrenheit.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabelFahrenheit.setText("Fahrenheit");

        jbtnConvert.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jbtnConvert.setText("Convert");
        jbtnConvert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnConvertActionPerformed(evt);
            }
        });

        jtfCelcius.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jtfCelcius.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtfCelciusKeyTyped(evt);
            }
        });

        jbtnKeluar.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jbtnKeluar.setText("Keluar");
        jbtnKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnKeluarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelGUILayout = new javax.swing.GroupLayout(jPanelGUI);
        jPanelGUI.setLayout(jPanelGUILayout);
        jPanelGUILayout.setHorizontalGroup(
            jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelGUILayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelFahrenheit)
                    .addGroup(jPanelGUILayout.createSequentialGroup()
                        .addGroup(jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCelcius)
                            .addComponent(jbtnConvert))
                        .addGap(65, 65, 65)
                        .addGroup(jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jbtnKeluar)
                            .addComponent(jtfCelcius, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanelGUILayout.setVerticalGroup(
            jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelGUILayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelCelcius)
                    .addComponent(jtfCelcius, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jLabelFahrenheit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(jPanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbtnKeluar)
                    .addComponent(jbtnConvert))
                .addGap(65, 65, 65))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelGUI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelGUI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnConvertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnConvertActionPerformed
       
        // TODO add your handling code here:
        double celcius;
        celcius = Double.parseDouble(jtfCelcius.getText()) * 1.8 + 32;
        jLabelFahrenheit.setText(celcius + " Fahrenheit");
    }//GEN-LAST:event_jbtnConvertActionPerformed

    private void jbtnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnKeluarActionPerformed
        // TODO add your handling code here:
     int jawab = JOptionPane.showOptionDialog(this, 
                    "Ingin Keluar?", 
                    "Keluar", 
                    JOptionPane.YES_NO_OPTION, 
                    JOptionPane.QUESTION_MESSAGE, null, null, null);
    
    if(jawab == JOptionPane.YES_OPTION){
        JOptionPane.showMessageDialog(this, "Program Akan Keluar");
        System.exit(0);
    }
    }//GEN-LAST:event_jbtnKeluarActionPerformed

    private void jtfCelciusKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtfCelciusKeyTyped
        // TODO add your handling code here:
                char k = evt.getKeyChar();
        if (!   ((Character.isDigit(k) ||
                  (k == KeyEvent.VK_BACKSPACE) ||
                  (k == KeyEvent.VK_DELETE))
                )) {
            getToolkit().beep();
            JOptionPane.showMessageDialog(null, "Masukkan hanyar 0-9!","Peringatan",JOptionPane.ERROR_MESSAGE);
            evt.consume();
    }//GEN-LAST:event_jtfCelciusKeyTyped
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CelciusToFahrenheitGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CelciusToFahrenheitGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CelciusToFahrenheitGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CelciusToFahrenheitGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CelciusToFahrenheitGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabelCelcius;
    private javax.swing.JLabel jLabelFahrenheit;
    private javax.swing.JPanel jPanelGUI;
    private javax.swing.JButton jbtnConvert;
    private javax.swing.JButton jbtnKeluar;
    private javax.swing.JTextField jtfCelcius;
    // End of variables declaration//GEN-END:variables
}
